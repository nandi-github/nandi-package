
def tst1():
    print("Welcome to TST")
