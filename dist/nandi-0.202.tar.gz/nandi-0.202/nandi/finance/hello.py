
def hell():
    print("Welcome to HELL")
